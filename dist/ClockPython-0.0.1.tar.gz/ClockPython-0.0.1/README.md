# ClockPython

A simple module that can get the current 24 or 12 hour time

## Examples

Example:

> Print(ClockPython.time(24))

23:00

Example 2:

> Time_Variable = ClockPython.time(12)

> Print(Time_Variable)

11:00

## Installation

To install type in command prompt:

"pip install ClockPython"

or, to install it in dev mode, locate the directory of ClockPython and type:

"pip install -e .[dev]"